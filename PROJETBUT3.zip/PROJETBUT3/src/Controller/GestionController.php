<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;
use App\Repository\EventRepository;

use App\Entity\Event;
use Doctrine\ORM\EntityManagerInterface;

use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class GestionController extends AbstractController
{
    #[Route('/gestion', name: 'app_gestion')]
    public function index(): Response
    {
        return $this->render('gestion/index.html.twig', [
            'controller_name' => 'GestionController',
        ]);
    }

    #[Route('/gestion/event', name: 'app_gestion_event')]
public function events(EventRepository $listEvents): Response
{
    return $this->render('gestion/event.html.twig', [
        'events' => $listEvents->findAll(),
        'controller_name' => 'GestionController',
    ]);
}
#[Route('/gestion/event/saisie/{id}', name: 'app_gestion_event_saisie')]
public function events_saisie(EventRepository $listEvents, EntityManagerInterface $em, Request $request, string $id = null): Response
{

$event = $id ? $listEvents->find($id) : null;

if ($id && !$event) {
    throw $this->createNotFoundException('événement non trouvé');
}

if (!$event) {
    $event = new Event();
}

    $form = $this->createFormBuilder($event)

        ->add(
            'title',
            TextType::class,
            [
                'required' => true,
                'label' => 'Titre', 
                'data' => $event ? $event->getTitle() : '',
                'attr' => [
                    'placeholder' => 'Username', 
                ]
            ]
        )
        ->add(
            'date_debut',
            TextType::class,
            [
                'required' => true,
                'label' => 'Date de début',
                'data' => $event ? $event->getDateDebut() : '',
                'attr' => [
                    'placeholder' => 'Date de début', 
                ]
            ]
        )
        ->add(
            'date_debut',
            TextType::class,
            [
                'required' => true,
                'label' => 'Date de fin',
                'data' => $event ? $event->getDateFin() : '',
                'attr' => [
                    'placeholder' => 'Date de fin',
                ]
            ]
        )
        ->add(
            'description',
            TextType::class,
            [
                'required' => true,
                'label' => 'Description', 
                'data' => $event ? $event->getDescription() : '',
                'attr' => [
                    'placeholder' => 'Description', 
                ]
            ]
        )
        ->add(
            'visibility',
            CheckboxType::class,
            [
                'required' => false,
                'label' => 'Public',
                'data' => $event->isVisibility(),
            ]
        )

        ->add('save', SubmitType::class, ['label' => $id ? 'Modify event' : 'Create event'])
        
        ->getForm();

    $form->handleRequest($request);

    if ($form->isSubmitted() && $form->isValid()) {
        if ($form->get('password')->getData()) {
            $encodedPassword = password_hash($form->get('password')->getData(), PASSWORD_BCRYPT);
            $user->setPassword($encodedPassword);
        }

        $em->persist($user);
        $em->flush();

        return $this->redirectToRoute('app_gestion_event');
    }

    return $this->render('gestion/event_saisie.html.twig', [
        'event' => $event,
        'form' => $form,
        'controller_name' => 'GestionController',
    ]);
}
}
